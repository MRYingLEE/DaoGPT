"use strict";
(self["webpackChunk_jupyterlab_examples_completer"] = self["webpackChunk_jupyterlab_examples_completer"] || []).push([["lib_index_js"],{

/***/ "./lib/customconnector.js":
/*!********************************!*\
  !*** ./lib/customconnector.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CustomCompleterProvider: () => (/* binding */ CustomCompleterProvider)
/* harmony export */ });
// Copyright (c) Jupyter Development Team.
// Distributed under the terms of the Modified BSD License.
/**
 * A custom connector for completion handlers.
 */
class CustomCompleterProvider {
    constructor() {
        this.identifier = 'CompletionProvider:custom';
        this.renderer = null;
    }
    /**
     * The context completion provider is applicable on all cases.
     * @param context - additional information about context of completion request
     */
    async isApplicable(context) {
        return true;
    }
    /**
     * Fetch completion requests.
     *
     * @param request - The completion request text and details.
     * @returns Completion reply
     */
    fetch(request, context) {
        const editor = context.editor;
        if (!editor) {
            return Promise.reject('No editor');
        }
        return new Promise(resolve => {
            resolve(Private.completionHint(editor));
        });
    }
}
/**
 * A namespace for Private functionality.
 */
var Private;
(function (Private) {
    /**
     * Get a list of mocked completion hints.
     *
     * @param editor Editor
     * @returns Completion reply
     */
    function completionHint(editor) {
        // Find the token at the cursor
        const token = editor.getTokenAtCursor();
        console.log('token:', token);
        let items = [];
        if (token.value === '@') {
            items.push({ label: 'Wukong' });
            items.push({ label: 'Bajie' });
            items.push({ label: 'Sha Seng' });
        }
        // // Create a list of matching tokens.
        // const tokenList = [
        //   { value: token.value + 'Magic', offset: token.offset, type: 'magic' },
        //   { value: token.value + 'Science', offset: token.offset, type: 'science' },
        //   { value: token.value + 'Neither', offset: token.offset }
        // ];
        // // Only choose the ones that have a non-empty type field, which are likely to be of interest.
        // const completionList = tokenList.filter(t => t.type).map(t => t.value);
        // // Remove duplicate completions from the list
        // const matches = Array.from(new Set<string>(completionList));
        // const items = new Array<CompletionHandler.ICompletionItem>();
        // matches.forEach(label => items.push({ label }));
        return {
            start: token.offset,
            end: token.offset + token.value.length,
            items
        };
    }
    Private.completionHint = completionHint;
})(Private || (Private = {}));


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_completer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/completer */ "webpack/sharing/consume/default/@jupyterlab/completer");
/* harmony import */ var _jupyterlab_completer__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_completer__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _customconnector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./customconnector */ "./lib/customconnector.js");



/**
 * Initialization data for the extension.
 */
const extension = {
    id: 'completer',
    description: 'Minimal JupyterLab extension setting up the completion.',
    autoStart: true,
    requires: [_jupyterlab_completer__WEBPACK_IMPORTED_MODULE_0__.ICompletionProviderManager, _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__.INotebookTracker],
    activate: async (app, completionManager, notebooks) => {
        completionManager.registerProvider(new _customconnector__WEBPACK_IMPORTED_MODULE_2__.CustomCompleterProvider());
        console.log('JupyterLab custom completer extension is activated!');
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (extension);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.8fd88a3b0657168f836e.js.map