# xeus-python + JupyterLite (0.2.0.x) playground
# Based on JupyterLab 4
